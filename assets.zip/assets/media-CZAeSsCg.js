function t(i){if(i)return i.startsWith("/media/")?`/api${i}`:i}export{t as m};
